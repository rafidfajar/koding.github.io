<html>
<head>
<title>Transaksi</title>
</head>
<body>
<b>Selamat datang di transaksi pembelajaran framework</b>
<hr>
Nama : <?php echo $nm;?>
<br>
Harga  : <?php echo $hrg;?>
<br>
Qty  : <?php echo $qty;?>
<hr>
Total transaksi adalah :<?php echo $total;?>
<br>

</body>
</html>