<html>
<head>
<title>balajar memahami masa depan </title>
</head>
<body>
<p>Menampilkan data array</p>
Data[1]: <?php echo $hasil[0];?>
<br>
Data[2]: <?php echo $hasil[1];?>
<br>
Data[3]: <?php echo $hasil[2];?>
<br>

</body>
</html>