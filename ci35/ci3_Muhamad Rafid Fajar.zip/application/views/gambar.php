<html>
<head>
<title>balajar memahami masa depan </title>
</head>
<body>
<p>Menampilkan gambar</p>
<div class="gambar" height="10px" width="auto" alt="inigambar">
    <img style="height:360px;width:auto;" src="<?php echo base_url('assets/img/balakang.jpg');?>">
</div>

</body>
</html>