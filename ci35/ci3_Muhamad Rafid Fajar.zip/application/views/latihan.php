<html>
<head>
<title>balajar memahami masa depan</title>
<link href="<?php echo base_url('css/bootstrap.min.css');?>"
 rel="stylesheet">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
</head>
<body style="background-color:#BDE9F7">
    <div class="container">
    <div class="jumbotron " style="background-color:#33CEFF">
        <center><div class="display-4"><b>Pembelajaran framework</b></div></center>
    </div>
   <hr>
<div class="row">
<div class="col-md-2">
<a class="btn btn-primary btn-block" href="<?php echo site_url('Aritmatika');?>">Materi aritmatika</a>
<br>
</div>
<div class="col-md-2">
<a class="btn btn-success btn-block" href="<?php echo site_url('Transaksi');?>">Transaksi</a>
<br>
</div>
<div class="col-md-2">
<a class="btn btn-warning btn-block" href="<?php echo site_url('Belajar_array');?>">Array</a>
<br>
</div>
<div class="col-md-2">
<a class="btn btn-info btn-block" href="<?php echo site_url('Gambar');?>">Gambar</a>
<br>
</div>
<div class="col-md-2">
<a class="btn btn-secondary btn-block" href="<?php echo site_url('Barang');?>">Materi database</a>
<br>
</div>
<div class="col-md-2">
<a class="btn btn-primary btn-block" href="<?php echo site_url('Customer');?>">Data customer</a>
</div>
</div>
<div class="row">
<div class="col-md-12">
<a class="btn btn-success btn-block" href="<?php echo site_url('Gambarku');?>">menyimpan gambar</a>
</div>
</div>
</div>
</body>
</html>