<html>
<head>
<title>Aritmatika</title>
</head>
<body>
<b>Selamat datang dipembelajaran framework</b>
<hr>
NIlai x adalah :<?php echo $x;?>
<br>
NIlai y adalah :<?php echo $y;?>
<hr>
Hasil dari penjumlahan adalah :<?php echo $hasil;?>
<br>
Hasil dari pengurangan adalah :<?php echo $hasil2;?>
<br>
Hasil dari perkalian adalah :<?php echo $hasil3;?>
<br>
Hasil dari pembagian adalah :<?php echo $hasil4;?>
<br>

</body>
</html>